
const verificaEdad=require('./verificaEdad');


describe('Testeo de la edad',()=>{
	beforeAll(()=>console.log("Empezamos con los test"));
	it('Testeo de edades válidad',()=>{
		expect(verificaEdad(18)).toBe(true);
		expect(verificaEdad(33)).toBe(true);
		expect(verificaEdad(40)).toBe(true);
	});
	it('Testeo de edades negativas',()=>{
		expect(verificaEdad(-1)).toThrow(Error);
		expect(verificaEdad(-20)).toThrow(Error);
	});
	it('Testeo de edades no válidas',()=>{
		expect(verificaEdad(0)).toBe(false);
		expect(verificaEdad(17)).toBe(false);
		expect(verificaEdad(41)).toBe(false);
		expect(verificaEdad(80)).toBe(false);
	});
}