function verificaEdad(edad){
	if(edad<0){
           throw new Error("No existen edades negativas");
        }
        if(edad<18){
            return false;
        }
        if(edad<41){
            return true;
        }
        else{
            return false;
        }
}


module.exports=verificaEdad;

